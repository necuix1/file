#!/bin/sh
python3 manage.py runserver 0.0.0.0:41450 --insecure
