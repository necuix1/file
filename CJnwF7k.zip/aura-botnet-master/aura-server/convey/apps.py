from django.apps import AppConfig


class ConveyConfig(AppConfig):
    name = 'convey'
